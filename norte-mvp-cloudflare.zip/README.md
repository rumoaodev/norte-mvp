# Norte — MVP

Protótipo estático da Norte, "Sua rota para empreender".

## Publicar no Cloudflare Pages
1. Entre no Cloudflare Dashboard.
2. Vá em Workers & Pages > Create application > Pages > Upload assets.
3. Arraste o conteúdo desta pasta (ou o ZIP extraído).
4. Dê um nome ao projeto, por exemplo `norte-mvp`.
5. Deploy.

Não há etapa de build: é HTML/CSS/JS puro.

## Escopo de segurança do protótipo
- Não coleta CPF ou credenciais gov.br.
- Não protocola solicitações.
- Calculadoras são simulações informativas.
- Casos fiscais/jurídicos específicos devem recomendar profissional habilitado.
